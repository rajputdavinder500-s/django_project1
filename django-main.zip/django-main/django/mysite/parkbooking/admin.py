from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Seats_Data

admin.site.register(Seats_Data)


