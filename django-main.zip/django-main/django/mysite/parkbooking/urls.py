from django.urls import path

from . import views

app_name = 'parkbooking'

urlpatterns = [
    path('', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('<int:user_id>/my_booking/', views.my_booking, name='my_booking'),
    path('<int:user_id>/my_booking/create_booking/',views.create_booking, name='create_booking')

]

