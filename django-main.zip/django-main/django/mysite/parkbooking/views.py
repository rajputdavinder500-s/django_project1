from django.http import request
from django.shortcuts import render,redirect

from django.shortcuts import get_object_or_404, render
from django.http import Http404



# Create your views here.

from .models import Users,My_Booking,Seats_Data
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse


def login(request):
	if request.method=="POST":
		email=request.POST["email"]
		password=request.POST["password"]
		print(email)
		print(password)
		try:
			user=Users.objects.get(email=email,password=password)
			return HttpResponseRedirect(reverse("parkbooking:my_booking",args=[user.id]))

		except Users.DoesNotExist:
			return HttpResponseRedirect(reverse("parkbooking:signup"))

	else:
		return render(request,"parkbooking/login.html")

def my_booking(request, user_id):
		
	return render(request,"parkbooking/mybooking.html",{"user_id":user_id})

def signup(request):
	if request.method == "POST":
		firstName=request.POST["firstname"]
		lastName=request.POST["secondname"]
		email=request.POST["email"]
		password=request.POST["password"]
		data={"firstName":firstName,"lastName":lastName,"email":email,"password":password}
		Users.objects.create(**data)
		
		return HttpResponseRedirect(reverse("parkbooking:login"))

	return render(request,"parkbooking/signup.html")





def create_booking(request,user_id):
	try:
		user = Users.objects.get(pk=user_id)
		name=user.firstName+ " " + user.lastName

	except Users.DoesNotExist:
		return render(request,"parkbooking/usernotexist.html")
	
	else:

		if request.method == "POST":
			print(type(request.POST["seats"]))
			seats=int(request.POST["seats"])
			date=request.POST["date"]
			seat_data=Seats_Data.objects.latest('date')
			current_price=seat_data.pricePerSeat
			# try has to be add okk !!!!!!!!!!! \

			seat_data.totalSeats=seat_data.totalSeats-seats
			seat_data.save()
			

			total_amount=seats*current_price

			#data={"total_amount":total_amount}
			mybooking_data={"seats":seats,"date":date,"amount":total_amount,"user_id":user}
			My_Booking.objects.create(**mybooking_data)

			return render(request,"parkbooking/createbooking.html",{"username":name,"total_amount":total_amount,"user_id":user_id})
		else:
			return render(request,"parkbooking/createbooking.html",{"user_id":user_id,"username":name})
