from django.apps import AppConfig


class ParkbookingConfig(AppConfig):
    name = 'parkbooking'
